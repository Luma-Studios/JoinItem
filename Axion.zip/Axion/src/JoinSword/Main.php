<?php

declare(strict_types=1);

namespace JoinSword;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\item\VanillaItems;
use pocketmine\item\Item;
use pocketmine\item\ItemIds;

class Main extends PluginBase implements Listener {

    public function onEnable(): void {
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $player = $event->getPlayer();

        // Create a diamond sword
        $sword = VanillaItems::DIAMOND_SWORD();
        $sword->setCustomName("§bSubscribe To TherealAcelx"); // Custom name with color

        // Give the sword to the player
        $player->getInventory()->addItem($sword);
    }
}
